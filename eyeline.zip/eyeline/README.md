# Eyeline

A small web app that tracks your screen time, estimates how it may be affecting your eyes, and prompts you to take breaks.

## Features

- **Break timer** with a dial that counts down to your next break. Defaults to the 20-20-20 rule: every 20 minutes, look at something 20 feet (6 m) away for 20 seconds. Start the break, snooze for 5 minutes, or skip it.
- **Eye strain estimate** (0 to 100: Fresh, Building, Tired, Strained) based on unbroken screen time, total time today and skipped breaks. The page shows how many points each factor adds.
- **Daily stats and a 7-day chart** of screen time against your goal, plus breaks taken out of breaks prompted.
- **Daily habits checklist**: seven small habits for screen distance, glare, brightness, text size and daylight.
- **Blink reset**: a guided 30-second set of ten slow blinks.
- **Settings**: break interval, break length, daily goal, optional chime.
- Light and dark themes follow your device setting.

## Run it

No build step and no dependencies. Open `index.html` in a browser.

The page loads three fonts from Google Fonts. Without a connection it falls back to system fonts and still works.

## Host it free on GitHub Pages

1. Create a new repository on GitHub and upload the contents of this folder (`index.html`, `style.css`, `script.js`, `README.md`).
2. Go to **Settings > Pages**.
3. Under **Build and deployment**, set **Source** to **Deploy from a branch**, choose the `main` branch and the `/ (root)` folder, then save.
4. After a minute your site is live at `https://<your-username>.github.io/<repository-name>/`.

## Files

| File | Purpose |
| --- | --- |
| `index.html` | Page structure |
| `style.css` | Styles, colour tokens and light/dark themes |
| `script.js` | Timer, strain model, chart, habits, blink exercise and saving |

## Notes and limits

- A web page cannot see your other apps or devices. The timer counts only while it is running on this page. Use "Screen time off this page" to add phone or TV time by hand.
- Data is saved in your browser's `localStorage`. It stays on your device and is not sent anywhere. Clearing site data removes it.
- On first load the 7-day chart shows an example week so you can see how it works. Press **Clear** to remove it.
- The strain score is an estimate from your timer, not a medical measurement. If eye pain, blurred vision or headaches keep coming back, see an optician or optometrist.

## Tweaking the strain model

The scoring lives in the `strain()` function in `script.js`. It adds up to 55 points for unbroken time, 30 for total time today and 15 for skipped breaks.
