(function () {
  var KEY = 'eyeline.v1';
  var $ = function (id) { return document.getElementById(id); };
  var HABITS = [
    { id: 'blink', t: 'Do one slow blink set', d: 'Ten full blinks bring moisture back to the surface of the eye.' },
    { id: 'dist', t: 'Screen at arm’s length', d: 'Roughly 50 to 70 cm from your eyes, so they are not working at close focus all day.' },
    { id: 'height', t: 'Top of the screen at eye level or just below', d: 'Looking slightly down lets your eyelids cover more of the eye and cuts dryness.' },
    { id: 'glare', t: 'Remove glare', d: 'Turn the screen side-on to windows and move any lamp that reflects in it.' },
    { id: 'bright', t: 'Match brightness to the room', d: 'A screen much brighter or darker than its surroundings makes your eyes work harder.' },
    { id: 'text', t: 'Make text big enough to read without leaning in', d: 'Squinting and leaning forward are early signs the text is too small.' },
    { id: 'outside', t: 'Spend ten minutes outside in daylight', d: 'Distance viewing is the best rest for the focusing muscles.' }
  ];
  var DEFAULTS = { interval: 20, breakSecs: 20, goalHrs: 6, sound: false };

  function dayKey(d) {
    d = d || new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  function addDays(n) { var d = new Date(); d.setDate(d.getDate() + n); return d; }

  var S = { settings: Object.assign({}, DEFAULTS), days: {}, sinceBreak: 0, snoozeUntil: 0, sample: true };
  var mode = 'idle', prevMode = 'idle', breakRemain = 0, wasDue = false, lastTick = Date.now(), ticks = 0, audio = null;

  function seedSample() {
    var hrs = [7.4, 6.8, 5.1, 6.2, 4.9, 2.6], taken = [8, 9, 6, 9, 7, 3], skipped = [5, 4, 7, 3, 2, 1];
    for (var i = 1; i <= 6; i++) {
      S.days[dayKey(addDays(-i))] = { secs: hrs[i - 1] * 3600, taken: taken[i - 1], skipped: skipped[i - 1], habits: [], sample: true };
    }
  }
  function load() {
    var raw = null;
    try { raw = localStorage.getItem(KEY); } catch (e) {}
    if (raw) {
      try {
        var p = JSON.parse(raw);
        S.settings = Object.assign({}, DEFAULTS, p.settings || {});
        S.days = p.days || {};
        S.sinceBreak = +p.sinceBreak || 0;
        S.snoozeUntil = +p.snoozeUntil || 0;
        S.sample = !!p.sample;
        return;
      } catch (e) {}
    }
    seedSample();
  }
  function save() {
    try {
      localStorage.setItem(KEY, JSON.stringify({ settings: S.settings, days: S.days, sinceBreak: S.sinceBreak, snoozeUntil: S.snoozeUntil, sample: S.sample }));
    } catch (e) {}
  }
  function today() {
    var k = dayKey();
    if (!S.days[k]) S.days[k] = { secs: 0, taken: 0, skipped: 0, habits: [] };
    return S.days[k];
  }

  /* ---------- formatting ---------- */
  function mmss(s) { s = Math.max(0, Math.ceil(s)); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); }
  function hm(secs) {
    var m = Math.round(secs / 60), h = Math.floor(m / 60);
    return h ? h + ' h ' + String(m % 60).padStart(2, '0') + ' min' : m + ' min';
  }

  /* ---------- strain model ---------- */
  function strain() {
    var intervalS = S.settings.interval * 60, d = today();
    var cont = Math.min(1, S.sinceBreak / (intervalS * 2.5)) * 55;
    var daily = Math.min(1, (d.secs / 3600) / (S.settings.goalHrs * 1.5)) * 30;
    var skip = Math.min(15, d.skipped * 3);
    var total = Math.round(Math.min(100, cont + daily + skip));
    var lvl = total < 25 ? 0 : total < 50 ? 1 : total < 75 ? 2 : 3;
    return { cont: Math.round(cont), daily: Math.round(daily), skip: Math.round(skip), total: total, lvl: lvl };
  }
  var LEVELS = ['Fresh', 'Building', 'Tired', 'Strained'];
  var ADVICE = [
    'Your eyes should feel comfortable. Keep blinking fully while you work.',
    'Blinking has probably slowed down. Do a blink reset, or look out of a window for a moment.',
    'Dryness, a tight brow or slight blur are common at this point. Take a proper break and look into the distance.',
    'Long unbroken focus raises the chance of dry, aching eyes and headaches. Step away from screens for a few minutes.'
  ];

  /* ---------- sound ---------- */
  function ensureAudio() {
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!audio && AC) audio = new AC();
      if (audio && audio.state === 'suspended') audio.resume();
    } catch (e) {}
  }
  function chime(freqs) {
    if (!S.settings.sound || !audio) return;
    try {
      freqs.forEach(function (f, i) {
        var o = audio.createOscillator(), g = audio.createGain(), t0 = audio.currentTime + i * 0.28;
        o.type = 'sine'; o.frequency.value = f;
        g.gain.setValueAtTime(0.0001, t0);
        g.gain.exponentialRampToValueAtTime(0.12, t0 + 0.03);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.6);
        o.connect(g); g.connect(audio.destination);
        o.start(t0); o.stop(t0 + 0.65);
      });
    } catch (e) {}
  }
  function announce(msg) { $('live').textContent = ''; setTimeout(function () { $('live').textContent = msg; }, 50); }

  /* ---------- actions ---------- */
  function isDue(now) { return mode === 'run' && S.sinceBreak >= S.settings.interval * 60 && now >= S.snoozeUntil; }

  function startPause() {
    ensureAudio();
    if (mode === 'idle') { mode = 'run'; lastTick = Date.now(); }
    else if (mode === 'run') { mode = 'idle'; save(); }
    render();
  }
  function beginBreak() {
    ensureAudio();
    if (mode !== 'break') prevMode = mode;
    mode = 'break'; breakRemain = S.settings.breakSecs; lastTick = Date.now();
    announce('Break started. Look about 6 metres away.');
    render();
  }
  function finishBreak() {
    var d = today(); d.taken++;
    S.sinceBreak = 0; S.snoozeUntil = 0;
    mode = prevMode === 'run' ? 'run' : 'idle';
    lastTick = Date.now();
    chime([660]);
    announce('Break complete.');
    save(); render();
  }
  function cancelBreak() { mode = prevMode === 'run' ? 'run' : 'idle'; lastTick = Date.now(); render(); }
  function skipBreak() { today().skipped++; S.sinceBreak = 0; S.snoozeUntil = 0; save(); render(); }
  function snooze() { S.snoozeUntil = Date.now() + 5 * 60 * 1000; save(); render(); }

  /* ---------- tick ---------- */
  function tick() {
    var now = Date.now(), dt = Math.min(120, Math.max(0, (now - lastTick) / 1000));
    lastTick = now; ticks++;
    if (mode === 'run') {
      today().secs += dt; S.sinceBreak += dt;
    } else if (mode === 'break') {
      breakRemain -= dt;
      if (breakRemain <= 0) { finishBreak(); return; }
    }
    var due = isDue(now);
    if (due && !wasDue) { chime([880, 660]); announce('Break due. Look about 6 metres away for 20 seconds.'); }
    wasDue = due;
    if (ticks % 5 === 0) save();
    render();
  }

  /* ---------- render ---------- */
  var C = 2 * Math.PI * 136;
  function buildIris() {
    var g = $('irisLines'), html = '';
    for (var i = 0; i < 72; i++) {
      var a = (i / 72) * Math.PI * 2, r1 = 56 + (i % 3) * 4, r2 = 102 + ((i * 7) % 5) * 2.4;
      html += '<line x1="' + (150 + Math.cos(a) * r1).toFixed(1) + '" y1="' + (150 + Math.sin(a) * r1).toFixed(1) +
        '" x2="' + (150 + Math.cos(a) * r2).toFixed(1) + '" y2="' + (150 + Math.sin(a) * r2).toFixed(1) + '"/>';
    }
    g.innerHTML = html;
  }

  function render() {
    var now = Date.now(), d = today(), st = strain(), due = isDue(now);
    var intervalS = S.settings.interval * 60;
    $('app').dataset.lvl = st.lvl;

    // dial
    var frac, read, label, eyebrow;
    if (mode === 'break') {
      frac = Math.max(0, breakRemain / S.settings.breakSecs);
      read = String(Math.ceil(breakRemain)); label = 'Look about 6 m away. Let your eyes relax.'; eyebrow = 'Break in progress';
      $('dial').setAttribute('aria-label', 'Break countdown, ' + Math.ceil(breakRemain) + ' seconds left');
    } else {
      frac = Math.min(1, S.sinceBreak / intervalS);
      var left = intervalS - S.sinceBreak;
      eyebrow = 'Next break';
      if (due) { read = '00:00'; label = 'Break due now'; }
      else if (mode === 'run' && S.sinceBreak >= intervalS) { read = '00:00'; label = 'Snoozed. Break due soon.'; }
      else if (mode === 'run') { read = mmss(left); label = 'until your next break'; }
      else { read = mmss(Math.max(0, left)); label = 'Paused. Press Start when you sit down.'; }
      $('dial').setAttribute('aria-label', 'Break countdown, ' + read + ' remaining');
    }
    $('prog').style.strokeDashoffset = (C * (1 - frac)).toFixed(1);
    $('readout').textContent = read;
    $('dialLabel').textContent = label;
    $('timerEyebrow').textContent = eyebrow;

    // buttons
    $('dueBox').hidden = !(due && mode === 'run');
    var sb = $('startBtn'), bn = $('breakNow');
    if (mode === 'break') { sb.textContent = 'Cancel break'; sb.classList.remove('primary'); bn.hidden = true; }
    else { sb.textContent = mode === 'run' ? 'Pause' : 'Start'; sb.classList.toggle('primary', mode !== 'run'); bn.hidden = false; }

    // title
    document.title = mode === 'break' ? 'Break · Eyeline' : due ? 'Break due · Eyeline' : mode === 'run' ? read + ' · Eyeline' : 'Eyeline';

    // strain
    $('score').textContent = st.total;
    $('levelName').textContent = LEVELS[st.lvl];
    $('marker').style.left = Math.min(99.5, st.total) + '%';
    $('meter').setAttribute('aria-valuenow', st.total);
    $('meter').setAttribute('aria-valuetext', st.total + ' out of 100, ' + LEVELS[st.lvl]);
    $('advice').textContent = ADVICE[st.lvl];
    $('fSince').textContent = 'Unbroken screen time: ' + Math.floor(S.sinceBreak / 60) + ' min';
    $('pSince').textContent = '+' + st.cont;
    $('fToday').textContent = 'Screen time today: ' + hm(d.secs);
    $('pToday').textContent = '+' + st.daily;
    $('fSkip').textContent = 'Breaks skipped today: ' + d.skipped;
    $('pSkip').textContent = '+' + st.skip;

    // stats
    $('sTotal').firstChild.nodeValue = hm(d.secs);
    $('sGoal').textContent = 'of ' + S.settings.goalHrs + ' h goal';
    $('sTaken').textContent = d.taken;
    $('sSkipped').textContent = d.skipped;
    $('sSince').textContent = mmss(S.sinceBreak);

    if (ticks % 10 === 0 || renderWeek.dirty) renderWeek();
  }

  function renderWeek() {
    renderWeek.dirty = false;
    var goal = S.settings.goalHrs * 3600, keys = [], vals = [], i;
    for (i = 6; i >= 0; i--) { var dt = addDays(-i); keys.push({ k: dayKey(dt), dt: dt, now: i === 0 }); }
    keys.forEach(function (o) { var r = S.days[o.k]; o.r = r; vals.push(r ? r.secs : 0); });
    var max = Math.max.apply(null, vals.concat([goal * 1.25]));
    var fmt = new Intl.DateTimeFormat('en-GB', { weekday: 'short' });
    var area = '', xl = '', xb = '', summary = [];
    keys.forEach(function (o, idx) {
      var secs = vals[idx], pct = (secs / max) * 100, hrs = secs / 3600, r = o.r || { taken: 0, skipped: 0 };
      var prompted = r.taken + r.skipped, name = o.now ? 'Today' : fmt.format(o.dt);
      var cls = 'bar' + (o.now ? ' today-bar' : '') + (secs > goal ? ' over' : '');
      area += '<div class="col"><div class="' + cls + '" style="height:' + pct.toFixed(1) + '%"></div>' +
        (secs > 0 ? '<div class="bar-val" style="bottom:calc(' + pct.toFixed(1) + '% + 4px)">' + hrs.toFixed(1) + '</div>' : '') + '</div>';
      xl += '<span' + (o.now ? ' class="now"' : '') + '>' + name + '</span>';
      xb += '<span>' + (prompted ? r.taken + '/' + prompted : '–') + '</span>';
      summary.push(name + ' ' + hrs.toFixed(1) + ' hours' + (prompted ? ', ' + r.taken + ' of ' + prompted + ' breaks' : ''));
    });
    var goalPct = (goal / max) * 100;
    var el = $('chart');
    el.innerHTML = '<div class="area">' + area + '<div class="goal" style="bottom:' + goalPct.toFixed(1) + '%"></div></div>' +
      '<div class="xl">' + xl + '</div><div class="xb">' + xb + '</div>';
    el.setAttribute('aria-label', 'Screen time for the last seven days. ' + summary.join('; ') + '. Daily goal ' + S.settings.goalHrs + ' hours.');
    $('sampleChip').hidden = !S.sample;
  }

  /* ---------- habits ---------- */
  function buildHabits() {
    var ul = $('habits');
    ul.innerHTML = HABITS.map(function (h) {
      return '<li><label class="habit" for="hb_' + h.id + '"><input type="checkbox" id="hb_' + h.id + '" data-h="' + h.id + '"><div><b>' + h.t + '</b><span>' + h.d + '</span></div></label></li>';
    }).join('');
    ul.addEventListener('change', function (e) {
      var id = e.target && e.target.getAttribute('data-h');
      if (!id) return;
      setHabit(id, e.target.checked);
    });
  }
  function setHabit(id, on) {
    var d = today(), i = d.habits.indexOf(id);
    if (on && i < 0) d.habits.push(id);
    if (!on && i >= 0) d.habits.splice(i, 1);
    save(); syncHabits();
  }
  function syncHabits() {
    var d = today();
    HABITS.forEach(function (h) { $('hb_' + h.id).checked = d.habits.indexOf(h.id) >= 0; });
    $('hCount').textContent = d.habits.length + ' / ' + HABITS.length;
  }

  /* ---------- blink reset ---------- */
  var bl = { on: false, n: 0, t: null };
  function eye(closed, cue) { $('eyeShape').classList.toggle('closed', closed); $('blinkCue').textContent = cue; }
  function blinkStep() {
    if (!bl.on) return;
    if (bl.n >= 10) { blinkEnd(true); return; }
    eye(true, 'Close slowly');
    bl.t = setTimeout(function () {
      if (!bl.on) return;
      eye(false, 'Open');
      bl.t = setTimeout(function () { bl.n++; $('blinkCount').textContent = bl.n + ' of 10 blinks'; blinkStep(); }, 1500);
    }, 1500);
  }
  function blinkEnd(done) {
    bl.on = false; clearTimeout(bl.t);
    eye(false, done ? 'Done. Your eyes should feel less dry.' : 'Ten slow blinks, about 30 seconds.');
    if (done) { $('blinkCount').textContent = 'Added to today’s habits.'; setHabit('blink', true); chime([660]); }
    else $('blinkCount').textContent = 'Slow, full blinks spread the tear film across the eye again.';
    $('blinkBtn').textContent = 'Start blink reset';
  }
  function blinkToggle() {
    ensureAudio();
    if (bl.on) { blinkEnd(false); return; }
    bl.on = true; bl.n = 0; $('blinkCount').textContent = '0 of 10 blinks'; $('blinkBtn').textContent = 'Stop';
    blinkStep();
  }

  /* ---------- tools & settings ---------- */
  function num(el, lo, hi, fallback) {
    var v = parseFloat(el.value);
    if (!isFinite(v)) return fallback;
    return Math.min(hi, Math.max(lo, v));
  }
  function bindSettings() {
    $('setInt').value = S.settings.interval;
    $('setBrk').value = S.settings.breakSecs;
    $('setGoal').value = S.settings.goalHrs;
    $('setSound').checked = !!S.settings.sound;
    $('setInt').addEventListener('change', function () { S.settings.interval = Math.round(num(this, 5, 60, 20)); this.value = S.settings.interval; save(); render(); });
    $('setBrk').addEventListener('change', function () { S.settings.breakSecs = Math.round(num(this, 10, 120, 20)); this.value = S.settings.breakSecs; save(); });
    $('setGoal').addEventListener('change', function () { S.settings.goalHrs = num(this, 1, 16, 6); this.value = S.settings.goalHrs; renderWeek.dirty = true; save(); render(); });
    $('setSound').addEventListener('change', function () { S.settings.sound = this.checked; if (this.checked) { ensureAudio(); chime([660]); } save(); });
  }
  var confirmTimer = null;
  function resetAll() {
    var b = $('resetAll');
    if (b.dataset.arm !== '1') {
      b.dataset.arm = '1'; b.textContent = 'Press again to delete everything';
      confirmTimer = setTimeout(function () { b.dataset.arm = ''; b.textContent = 'Delete all saved data'; }, 4000);
      return;
    }
    clearTimeout(confirmTimer);
    S = { settings: Object.assign({}, DEFAULTS), days: {}, sinceBreak: 0, snoozeUntil: 0, sample: false };
    mode = 'idle'; save();
    b.dataset.arm = ''; b.textContent = 'Delete all saved data';
    $('setInt').value = DEFAULTS.interval; $('setBrk').value = DEFAULTS.breakSecs; $('setGoal').value = DEFAULTS.goalHrs; $('setSound').checked = false;
    syncHabits(); renderWeek.dirty = true; render();
  }

  /* ---------- init ---------- */
  load();
  S.sample = S.sample && Object.keys(S.days).some(function (k) { return S.days[k].sample; });
  buildIris(); buildHabits(); bindSettings();
  $('dateLabel').textContent = new Intl.DateTimeFormat('en-GB', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date());

  $('startBtn').addEventListener('click', function () { if (mode === 'break') cancelBreak(); else startPause(); });
  $('breakNow').addEventListener('click', beginBreak);
  $('doBreak').addEventListener('click', beginBreak);
  $('snooze').addEventListener('click', snooze);
  $('skip').addEventListener('click', skipBreak);
  $('blinkBtn').addEventListener('click', blinkToggle);
  $('resetAll').addEventListener('click', resetAll);
  $('clearSample').addEventListener('click', function () {
    Object.keys(S.days).forEach(function (k) { if (S.days[k].sample) delete S.days[k]; });
    S.sample = false; save(); renderWeek.dirty = true; render();
  });
  $('addBtn').addEventListener('click', function () {
    var m = Math.round(num($('addMin'), 1, 600, 0));
    if (!m) { $('addFb').textContent = 'Enter a number of minutes between 1 and 600.'; return; }
    today().secs += m * 60; save(); renderWeek.dirty = true; render();
    $('addFb').textContent = 'Added ' + m + ' min to today.';
  });
  document.addEventListener('visibilitychange', function () { if (document.hidden) save(); });
  window.addEventListener('pagehide', save);

  syncHabits(); renderWeek.dirty = true; render();
  setInterval(tick, 1000);
})();
